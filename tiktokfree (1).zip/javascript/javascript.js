function aChat(){
  var lines = [
    "Topcatz: No",
"Sjvir: TikTok followers working fine",
"Diamond: a friend told me about this",
"Jacka: omg stop asking how to get TikTok followers just get it from generator",
"PorpoiseDeluxe: What can I do here?",
"HentaiKatness69: man servers are always down fuk it",
"yorozu: thank you for giving me TikTok followers!",
"Hauntzer: Is this for real guys?",
"FluffyKittens206: can i do this with my nexus phone?",
"MARSIRELIA: okay",
"r0b0cop: Real",
"AbsoluteFridges: this website is used a lot sometimes you have to wait a bit",
"SireSnoopy: nice page for TikTok followers",
"Grandederp: had to reload page before it worked",
"TheBiddler: any bro needs help?",
"CcLiuShicC: noobs pls if you dont know how to do it dont spam here okay",
"Polx: i have tried too many surveys in my life finally i got lucky here",
"AdrianMa: thank you!",
"VwSKhoachitizer: you can have reginalds IQ and still be able to get TikTok followers",
"AirscendoSona: uhm",
"Scrumm: is this twitch chat?",
"Anoledoran: I love this",
"HOGEE: great i can test the expansion before purchasing it",
"14h: brb",
"AllianceMike: where do you come from?",
"Lovelyiris: hi guys",
"Abidius: thanks to whoever pmed me it worked",
"Doublelift: I generated 100000 TikTok followers can't wait to start.",
"Kevnn: i havent seen this before but im impressed with the result!",
"YahooDotCom: where did you find this?",
"XerbeK: my boyfriend will freak out :D",
"TanHat: derp",
"intero: instagram sucks hahahaha",
"ElvishGleeman: Do TikTok followers expire?",
"Preachy: if you want a proof add me on skype",
"zgerman: incredible",
"LemonBoy: now the secret is solved",
"WildTurtle: I can't wait anymoreeee",
"Nihillmatic: I would be so sad if this did not work because it took a while thankfully it worked then",
"MikeytheBully: How much TikTok followers u made so far?",
"IamOsiris: Where do i put my phone",
"HurricaneJanna: hi all who has some TikTok followers for me",
"silvermidget: this worked lol",
"Raimazz: wow 10 minutes ago this was empty now all people here wtf",
"C9LOD: you think this will be patched any time soon",
"St1xxay: does this giveaway go forever?",
"TGZ: i think everyone here got TikTok followers",
"LiquidXpecial: i am looking for a friend please pm me",
"RayXu: i dont rly like instagram anymore",
"Tahx: oh god",
"Zik: What you think about all this",
"KevonBurt: I had a bit trouble with some survy thing but no problem if you just choose an easy",
"Martel: i begin to like this very much. third pack i unlocked",
"KatLissEverdeen: ROFL!",
"lovemyRMB: actually i had no problem with any survey ever just try?",
"CLGThink: hope not too many kids in this chat",
"ELMdamemitai: this works for EU players rTikTokht?",
"CeIestic: damn",
"GrTikTokne: are you not bored at all? i cant wait for expansion pack",
"HatersWantToBeMe: Why this is so easy lol?",
"Wardrium: surveys dont appaer every time but i think its there to have enough money for the website to buy get the TikTok followers codes",
"Frostalicious: used this three times and applied for 3x 5000 followers lol see you ingame suckers",
"m2sticc: nice",
"Phanimal: saw this on forums pretty impressive",
"Pokemorph: why would someone just go here to hate and spam pff",
"XiaoWeiXiao: how much can you even have",
"Shade20: can I get for free?",
"Arakune: i am curious is this legit?",
"cre4tive: haha",
"maplestreeTT: servers i tested this and its working",
"Taeyawn: what?",
"BarronZzZ: Anyone tried this already?",
"Aror: dont regret being here",
"Slylittlefox121: check my profile i am rich",
"Protective: not sure if i understood? its all free rTikTokht?",
"tongsoojosim: did you try 14500 pack yet? I used on NA but maybe other locations can use it too",
"UnKooL: hi my english no good i here get TikTok followers?",
"HotGuy6Pack: josh are you here?",
"EmilyVanCamp: ten minutes",
"KissMeRDJ: this makes my game more enjoyable i hope",
"Stan007: shadow fTikTokht sucks noobs haha",
"Ina: i love this generator so much",
"MrJuneJune: ok sounds good enough for me bros",
"irvintaype: thank you for messaging me man",
"DragonxCharl: what was the newest expansion",
"IlIIlIIIlIIIIIII: best TikTok followers website",
"Mookiez: i was stuck in survey had to do again but it worked then",
"DeliciousMilkGG: wow really many people online here",
"AAltec: my friends on facebook spam this like every day they are rly happy about it",
"NiHaoDyLan: Yea",
"whiteclaw: any idea how long it takes for TikTok followers to come?",
"Shoopufff: god thanks for this generator finally",
"FENOMENO: bro",
"GVKeane: which country are you playing in guys?",
"onelaugh: so when will TikTok followers start?",
"VANISHINGDRAG0N: PM me pls",
"TedStickles: i see most people here write positive things it is true?",
"Maulface: thank you all for helping me out bros",
"ProofOfPayment: Can anyone do it for me? My username is brazilinaronaldo",
"TDKNear: maybe",
"JustJayce: guys this is so easy it takes less than a minute",
"Dreemo: so you can buy 10 TikTok followers now guys?",
"Remie: fucking hilarious some people",
"Isunari: thanks to whoever spams this website lol",
"194IQredditor: where i put in my code?",
"RiotChun: fucking is real",
"ImJinAh: saw on stream yo",
"Daydreamin: ios player here works flawless.",
"Hiphophammer: you like this?",
"HomedogPaws: Likely but I think one day this will fail",
"FlyinpTikTokgy: this still works at the moment",
"Aerodactyl: Never imagined this would work but damn its so simple",
"LiquidInori: I know",
"xrawrgasm: yes i got it too",
"Docxm: Exactly what I think",
"Hoeji: Exactly why this is so good",
"iMysterious: You should give it a try",
"CptJack: even noobs can do this",
"Destinedwithin: when i came first to this website i was like most of you guys just spamming here the chat in the end im glad that i tried it because now for next year or so i am not leaving my room",
"WWvvWvvWvvwWwvww: How much TikTok followers can I generate?",
"sweetinnocence: today is lucky day",
"Vanxer: ty for the TikTok followers opt in guys!",
"sakurafIowers: I want to play from korea",
"Entus: hey i am a newbie will i be able to play?",
"7Qing: anyone up for a game?",
"baohando: pretty sure this is saving me a lot of money",
"Aniratak: OMG!",
"DifferentSword: yo guys dont spam okay?",
"X1337Gm4uLk03rX: i wasted so much money on buying followers lol - good this is free here",
"LogicalDan: yayy",
"CatVomit: any idea if this still works tomorrow",
"iKoogar: ...^^",
"TheItalianOne: you guys watch nTikTokhtblue?",
"xPepastel: can't wait for it to start!",
"TooPro4u: i think some offers easier in countries like USA",
"Splorgen: bye guys",
"delirous: Cool =)",
"GVBunnyFuFuu: Is this free?",
"DD666666: Does it work in NA?",
"TSMLustboy: when can I play I am new to this",
"Baesed: i am fine with having free TikTok followers how about you",
"Dusty: i sTikTokned up now the waiting starts :/ i hope they will launch sooner",
"KittenAnya: LOL!",
"AKASIeepingDAWG: i would do screenshot but maybe you report me then",
"Panchie: fucking helll! got my TikTok followers!.",
"SawitonReddit: Works on OCE?",
"DAKular: what you can get TikTok followers here for free?",
"xFSNSaber: hi again im here for more TikTok followers",
"Link: what i always disliked is when you get close to release date and they move it even further",
"DouyuTVForgottt: pretty good TikTok followers sTikToknup form guys",
"RambointheJungle: funny how this works but it does like always",
"Indivisible: when did you guys start playing wow",
"sh4pa: just wow",
"1stTimeDraven: worth",
"hiimria: great generator good i found this",
"Penguinpreacher: fuck i have no surveys left had like 50k already on my acc",
"MochiBalls: need to go now",
"AiShiTeru: think so",
"sooyoung: Shut up man I love this website",
"Firehazerd: How long do you have to wait?",
"LiquidQuas: Where do I get my TikTok followers?",
"Upu: just dodged queue for this",
"HooManDu: i agree",
"Jibberwackey: yeah free TikTok followers is cool",
"Sprusse: lol ProAsh32 is here? you were in my skype! how are you guy",
"MrCow: from all websites ive been on this is the first and probably the only one which rly gives you the TikTok followers",
"Heejae: This is incredible never thought it would work.",
"CopyCat: i checked some of the people accounts here they are actually real humans maybe not all though",
"Chimonaa1: worth got my TikTok followers key",
"Normalize: i can only recommend this stuff",
"RedBerrrys: TikTok followers here I come",
"cackgod: unlocking takes some time for me",
"BlueRainn: i need some TikTok followers what do i do",
"AsianSGpotato: wow i waited ages to get a server transfer now here it shouldnt be a problem anymore",
"DGB: anyone reddit here?",
"kevybear: TikTok followers for free?",
"LevelPerfect: think so man",
"fwii: i play in EU",
"Mruseless: i feel like this will be the best! it was starting to get boring lol",
"Jintea: I thought instagram? is slowly dying",
"vane: this is the best TikTok followers website because we all have more than a chance",
"Imacarebear: I got bTikTok pack of TikTok followers for my girlfriend making her happy and i dont pay for them lol",
"FSNMeMer: aasdasdasd",
"WildTurtl: okay i applied thank you",
"JGLafter: who is up for a chat hehe?",
"CHRISTHORMANN: anyone not here for free followers lol?",
"Isuyu: i can imagine that",
"LAGCoinsenShiv: I have seen this website on twitch stream i think",
"TheEyeofHorus: i usually choose the first offer in the list because its normally the easiest one",
"Chiruno: imagine all the people waiting fo this",
"Xeralis: Thanks man I appreciate this.",
"JRT94: Okay I believe this works cus I just logged in and saw my TikTok followers ROFL",
"JannaFKennedy: i wish i found this earlier",
"drallaBnayR: when do you wanna play?",
"Nickywu: so happy i found this",
"Blackmill: i think with the new game mTikTokht become somewhat more interesting",
"DaBox: i thought my friend wanted to fool me with this website link. but you can rly get TikTok followers here if you dont mess up with the survey part",
"AlliancePatrick: what about surveys on mobile phone?",
"ArcticPuffin11: i see no limits on how TikTok followers you can get thats so epic",
"Sunohara: easy",
"Ariana22ROO: Ok so I am back and what I can say is that i got my TikTok followers! I can not do a screenshot cus the chat would block any links meh but rly go try it its worth it",
"FasScriptor: ok cool",
"QuantumFizzics: where do all of you come from",
"OberonDark: so far I am cool with this",
"TwitchTvAuke: when is TikTok followers start men?",
"TikTokgypop: EA pls",
"BonQuish: how come i dont see any trolls here"
  ];



  setInterval(function(){
    var objDiv = document.getElementsByClassName("innerchat")[0];
    objDiv.scrollTop = objDiv.scrollHeight;
    var n = lines.length;
    var toDraw = Math.floor(Math.random() * n);

    var splited = lines[toDraw].split(":");

    var para = document.createElement("P");
    // para.className = "redchat";
    var appendingTo = document.getElementsByClassName("innerchat")[0];
    para.innerHTML = '<span class="redchat">'+ splited[0] + ': ' + '</span>' + splited[1];
    appendingTo.appendChild(para);

  }, 1200);
}

var globalINP = "";

function butnext() {
  var inpVal = document.getElementById("username").value;
  globalINP = inpVal;
  if(!inpVal.includes("@")){
    document.getElementById("username").classList.add("alertingg");
    setTimeout(function () {
      document.getElementById("username").classList.remove("alertingg");
    }, 350);
  }
  else{
    // var eleSize = document.getElementsByClassName("mainStuff")[0].offsetWidth;
    var eleHeight = document.getElementsByClassName("mainStuff")[0].offsetHeight;
    // document.getElementsByClassName("mainStuff")[0].style.width = eleSize+"px";
    document.getElementsByClassName("mainStuff")[0].style.height = eleHeight+"px";

    document.getElementsByClassName("din")[0].innerHTML = globalINP;

    setTimeout(function () {
      document.getElementsByClassName("tHolder")[0].style.opacity = 0;
    }, 800);
    setTimeout(function () {
      document.getElementsByClassName("tHolder")[0].style.display = "none";
    }, 1400);
    setTimeout(function () {
      document.getElementsByClassName("sStep")[0].style.display = "flex";
    }, 1410);
    setTimeout(function () {
      document.getElementsByClassName("sStep")[0].style.opacity = 1;
    }, 1420);
    setTimeout(function () {
      document.getElementsByClassName("sStep")[0].style.opacity = 0;
    }, 6000);
    setTimeout(function () {
      document.getElementsByClassName("sStep")[0].style.display = "none";
    }, 6500);
    setTimeout(function () {
      document.getElementsByClassName("tStep")[0].style.display = "flex";
    }, 6510);
    setTimeout(function () {
      document.getElementsByClassName("tStep")[0].style.opacity = 1;
    }, 6520);


  }
}



function selectedPackage(event) {
  var target = event.target;
  var parent = target.parentElement;//parent of "target"

  document.getElementsByClassName("apppending")[0].style.pointerEvents = "none";

  document.getElementsByClassName("aaaaa")[0].innerHTML = globalINP;

  document.getElementsByClassName("tStep")[0].style.opacity = 0;

  setTimeout(function () {
    document.getElementsByClassName("tStep")[0].style.display = "none";
  }, 510);

  setTimeout(function () {
    if(parent.classList.contains("ppp")){
      document.getElementsByClassName('apppending')[0].appendChild(parent);
    }
    else{
      document.getElementsByClassName('apppending')[0].appendChild(target);
    }
  }, 525);

  setTimeout(function () {
    document.getElementsByClassName("fStep")[0].style.display = "flex";
  }, 520);
  setTimeout(function () {
    document.getElementsByClassName("fStep")[0].style.opacity = 1;
  }, 530);

  setTimeout(function () {
    move();
  }, 1550);
}


function move() {

  // document.getElementsByClassName("addedd")[0].style.pointerEvents = "none";

  var elem = document.getElementsByClassName('progress')[0];
  var wholeBox = document.getElementsByClassName('progress-wrapper')[0];
  var myContent = document.getElementsByClassName('percentages')[0];
  var myInterval = 55;
  wholeBox.style.display = "flex";
  var width = 1;
  var id = setInterval(frame, myInterval);
  function frame() {
    if (width >= 99) {
      clearInterval(id);
    }
    else {
      width++;
      elem.style.width = width + '%';
      myContent.innerHTML = width * 1 + '%';
    }

    //Dynamic status changes
    if(width >= 1 && width <= 25){
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Preparing Script " + myContent.innerHTML;
    }

    if(width >= 25 && width <= 33){
      myInterval = 1190;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Launching Script " + myContent.innerHTML;
    }
    if(width >= 33 && width <= 45){
      myInterval = 180;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Encripting Data " + myContent.innerHTML;
    }
    if(width >= 45 && width <= 55){
      myInterval = 380;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Sending Json Packets " + myContent.innerHTML;
    }
    if(width >= 55 && width <= 67){
      myInterval = 580;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Injecting Followers " + myContent.innerHTML;
    }
    if(width >= 67 && width <= 89){
      myInterval = 210;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Bypassing Verification " + myContent.innerHTML;
    }
    if(width >= 89 && width <= 96){
      myInterval = 555;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Decrypting Captcha " + myContent.innerHTML;
    }
    if(width >= 96 && width <= 98){
      myInterval = 4000;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Injecting Token " + myContent.innerHTML;
    }
    if(width >= 98 && width <= 99){
      myInterval = 4000;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Auto Verification Failed " + myContent.innerHTML;
    }
    if(width >= 99 && width <= 99){
      myInterval = 1000;
      var ll = document.getElementsByClassName('ll1')[0];
      ll.innerHTML = "Manual Verification Required " + myContent.innerHTML;
      // document.getElementsByClassName("addedd")[0].style.opacity = 1;
      // document.getElementsByClassName("addedd")[0].style.pointerEvents = "auto";
      document.getElementsByClassName("detsss")[0].style.opacity = 0;
      setTimeout(function () {
        document.getElementsByClassName("detsss")[0].style.display = "none";
      }, 10);
      setTimeout(function () {
        document.getElementsByClassName("verifyy")[0].style.display = "flex";
      }, 510);
      clearInterval(id);
    }

    if(width >= 25 && width < 99){
      clearInterval(id);
      // myInterval = 80;
      id = setInterval(frame, myInterval);
      // var ll = document.getElementsByClassName('ll1')[0];
      // ll.innerHTML = "Loading..." + myContent.innerHTML;
    }
  }
}
